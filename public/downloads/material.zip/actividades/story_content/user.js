function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6fN38kuDhRa":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

